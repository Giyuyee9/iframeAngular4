export const environment = {
  production: true,
  getProductPricingAPIUrl: 'http://rn-dcf5t-lapp17.rno.apple.com:8087/admin/getProduct',
  getLobListAPIUrl: 'http://rn-dcf5t-lapp17.rno.apple.com:8087/admin/getLob',
  getStoreListAPIUrl: 'http://rn-dcf5t-lapp17.rno.apple.com:8087/admin/getStore',
  downloadPriceTemplateAPIUrl : 'http://rn-dcf5t-lapp17.rno.apple.com:8087/admin/price/template/download',
  hideAssortmentAPIUrl: 'http://rn-dcf5t-lapp17.rno.apple.com:8087/admin/assortment/hide',
  devicesAPIUrl: 'http://rn-dcf5t-lapp17.rno.apple.com:8084/en_US/iphone/index.html',
  storeListTablePageSize: 10,
  storeListTableRecordsCount: 200,
  visiablePageCount: 5
};
