// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.

export const environment = {
  production: false,
  // getProductPricingAPIUrl: 'http://rn-dcf5t-lapp17.rno.apple.com:8087/admin/getProduct',
  // getLobListAPIUrl: 'http://rn-dcf5t-lapp17.rno.apple.com:8087/admin/getLob',
  // getStoreListAPIUrl: 'http://rn-dcf5t-lapp17.rno.apple.com:8087/admin/getStore',
  // downloadPriceTemplateAPIUrl : 'http://rn-dcf5t-lapp17.rno.apple.com:8087/admin/price/template/download',
  // devicesAPIUrl: 'http://rn-dcf5t-lapp17.rno.apple.com:8084/en_US/iphone/index.html',
  // hideAssortment: 'http://rn-dcf5t-lapp17.rno.apple.com:8084/admin/assortment/hide',
  getProductPricingAPIUrl: 'http://rn-dcf5t-lapp15.rno.apple.com:8087/admin/getProduct',
  getLobListAPIUrl: 'http://rn-dcf5t-lapp15.rno.apple.com:8087/admin/getLob',
  getStoreListAPIUrl: 'http://rn-dcf5t-lapp15.rno.apple.com:8087/admin/getStore',
  downloadPriceTemplateAPIUrl : 'http://rn-dcf5t-lapp15.rno.apple.com:8087/admin/price/template/download',
  devicesAPIUrl: 'http://rn-dcf5t-lapp17.rno.apple.com:8087/admin/getPreviewContent/',
  hideAssortmentAPIUrl: 'http://rn-dcf5t-lapp15.rno.apple.com:8087/admin/assortment/hide',
  storeListTablePageSize: 10,
  storeListTableRecordsCount: 200,
  visiablePageCount: 5
};
