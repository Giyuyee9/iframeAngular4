import { Injectable } from '@angular/core';

import { FormData }  from './form-data.model';
import {SubLobPricingDetails} from '../shared/models/sub-lob-pricing-details.model';
import {SubLob} from '../shared/models/sublob.model';
import { ProductlistDetails } from '../shared/models/productlist-details.model';
import {StoreListDetails} from "../shared/models/storelist-details.model";
import {StoreDetails} from "../shared/models/store-details.model";

@Injectable()
export class FormDataService {

    constructor() { }

    private formData: FormData = new FormData();
    private isStoreListFormValid: boolean = false;
    private isProductListFormValid: boolean = false;
    private isPriceUpdateFormValid: boolean = false;
    private isWorkFlowSelectionValid: boolean = false;

    getProductsListDetails(): any {
        // Return the product list details
        var productListDetails: ProductlistDetails;
        productListDetails = this.formData.productListDetails;
        return productListDetails;
    }
    setProductsListDetails(data: any) {
      this.isProductListFormValid = true;
      this.formData.productListDetails = new ProductlistDetails();
      this.formData.productListDetails.lobList = data.productsList;
      this.formData.productListDetails.selectedLobItem = data.selectedLobItem
    }

    getSubLobPricingDetails(): SubLobPricingDetails {
        // Return the SubLob Pricing details
        var subLobPricingDetails: SubLobPricingDetails;
        subLobPricingDetails = this.formData.subLobPriceDetails;
        return subLobPricingDetails;
    }

    getSubLobPricingDetailsModified(): SubLobPricingDetails {
        // Return the SubLob Pricing details
        var subLobPricingDetails: SubLobPricingDetails;
        subLobPricingDetails = this.formData.subLobPriceDetailsModified;
        return subLobPricingDetails;
    }
    setSubLobPricingDetails(data : any) {
        // Update the SubLob Pricing details
        this.isPriceUpdateFormValid = true;
        this.formData.subLobPriceDetails = new SubLobPricingDetails();
        this.formData.subLobPriceDetails.lobName = data.value.lobName;
        this.formData.subLobPriceDetails.subLobPriceDetails  = data.value.subLobPriceDetails.map((subLob: SubLob) => new SubLob().deserialize(subLob));

        this.formData.subLobPriceDetailsModified = new SubLobPricingDetails();
        this.formData.subLobPriceDetailsModified.lobName = data.valuesModified.lobName;
        this.formData.subLobPriceDetailsModified.subLobPriceDetails  = data.valuesModified.subLobPriceDetails.map((subLob: SubLob) => new SubLob().deserialize(subLob));


        // this.formData.subLobPricingDetails.subLobPriceDetails: SubLob[];
        // data.subLobPriceDetails.map((subLob: SubLob) => new SubLob().deserialize(subLob));;
    }

    setWorkFlowSelection(data: any) {
      this.formData.workflowSelection = data;
      this.isWorkFlowSelectionValid = true;
    }
    getWorkFlowSelection() {
      return this.formData.workflowSelection;
    }

    getSelectedStoreListDetails(): StoreListDetails{
        var selectedStoreListDetails: StoreListDetails;
        selectedStoreListDetails = this.formData.selectedStoreListDetails;
        return selectedStoreListDetails;
    }

    setSelectedStoreListDetails(data: any){
        this.formData.selectedStoreListDetails = new StoreListDetails();
        this.formData.selectedStoreListDetails.storeList = data.map((storeDetails: StoreDetails) => new StoreDetails().deserialize(storeDetails));
        this.isStoreListFormValid = true;
    }

    getFormData(): FormData {
        // Return the entire Form Data
        return this.formData;
    }

    resetFormData(): FormData {
        // Return the form data after all this.* members had been reset
        this.formData.clear();
        this.isStoreListFormValid = this.isPriceUpdateFormValid = this.isProductListFormValid = false;
        return this.formData;
    }

    isFormValid() {
        // Return true if all forms had been validated successfully; otherwise, return false
        return this.isStoreListFormValid &&
                this.isPriceUpdateFormValid &&
                this.isProductListFormValid;
    }

    currentFormStatus(step: string) {
      let status = false;
      if (step === 'storeslist') {
        status = this.isStoreListFormValid;
      }
      else if (step === 'productlist') {
        status = this.isProductListFormValid;
      }
      else if (step === 'updateprice') {
        status = this.isPriceUpdateFormValid;
      }
      return status;
    }
}
