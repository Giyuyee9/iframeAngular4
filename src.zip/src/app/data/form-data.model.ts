import {SubLob} from '../shared/models/sublob.model';
import {SubLobPricingDetails} from '../shared/models/sub-lob-pricing-details.model';
import { ProductlistDetails } from '../shared/models/productlist-details.model';
import {StoreListDetails} from "../shared/models/storelist-details.model";

export class FormData {
    firstName: string = '';
    lastName : string = '';
    email: string = '';
    work: string = '';
    street: string = '';
    city: string = '';
    state: string = '';
    zip: string = '';

    workflowSelection: string = '';

    id: string = '';
    name: string = '';
    mpn: string = '';
    mpnDisplayName: string = '';
    posIds = [];
    subLobId: string = '';
    affordability: string = '';
    appleTC: string = '';
    geoSpecificLegal: string = '';
    mpnPartnerName: string = '';
    otherPricesAvailable: string = '';
    partnerTC: string = '';
    partnetPosId: string = '';
    planName: string = '';
    supportingCopy: string = '';
    valueProposition: string = '';
    price: string = '';
    priceOptionName: string = '';
    priceContractTerm: string = '';


    productListDetails: ProductlistDetails;

    subLobPriceDetails: SubLobPricingDetails;
    subLobPriceDetailsModified: SubLobPricingDetails;

    selectedStoreListDetails: StoreListDetails;
    clear() {
        // this.firstName = '';
        // this.lastName = '';
        // this.email = '';
        // this.work = '';
        // this.street = '';
        // this.city = '';
        // this.state = '';
        // this.zip = '';
        this.productListDetails.lobList = [];
        this.productListDetails.selectedLobItem = '';
        this.subLobPriceDetails.lobName = '';
        this.subLobPriceDetails.subLobPriceDetails.map((item: SubLob) => {
          item.id = '',
          item.name = '',
          item.mpnList = [];
        })
    }
}

// export class Personal {
//     firstName: string = '';
//     lastName : string = '';
//     email: string = '';
// }

// export class Address {
//     street: string = '';
//     city: string = '';
//     state: string = '';
//     zip: string = '';
// }
