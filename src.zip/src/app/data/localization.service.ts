import { Injectable } from '@angular/core';

@Injectable()
export class LocalizationService {

  data: any;

  constructor() { }

  getLocalizationDetails(): any {
    return this.data;
  }
  setLocalizationDetails(data: any) {
    this.data = data;
  }
  public getLocalization(key: string) {
    return this.data[key];
  }
}
