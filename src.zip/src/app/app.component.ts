import {Component, OnInit} from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs/Subscription';

import { AppLandingService} from './common/services/app-landing.service';
import { UserInfoDetails } from './shared/models/user-info-details.model';
import {LocalizationService} from './data/localization.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'app';
  loading = true;
  private headerViewSubscription: Subscription;

  constructor(private router: Router,
            public appLandingService: AppLandingService, private locale: LocalizationService) { }

  ngOnInit() {
    this.headerViewSubscription = this.appLandingService.getLocalizationDetails().subscribe((localization: any) => {
      this.locale.setLocalizationDetails(localization);
      this.loading = false;
    });
  }

  onSelLogout() {
    this.appLandingService.logout();
  };
  ngOnDestroy() {
    this.headerViewSubscription.unsubscribe();
  }
}
