import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';

import {AppRoutingModule} from './app-routing.module';
import {HelperService} from './common/services/helper.service';
import { UtilService } from './common/services/util.service'
import { AppComponent } from './app.component';
import { CoreModule } from './core/core.module';
import { DataModule } from './data/data.module';
import { SharedModule } from './shared/shared.module';
import { HeadernavModule } from 'pricingweb-uicomponents';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { StoreslistModule } from './storeslist/storeslist.module';
import { PricingModule } from './pricing/pricing.module';
import { ProductsModule } from './products/products.module';
import {WebPreviewModule} from './web-preview/web-preview.module'
import { AppLandingService } from './common/services/app-landing.service';
import {LocalizationService } from './data/localization.service';

@NgModule({
  declarations: [
    AppComponent,
    PageNotFoundComponent
  ],
  imports: [
    BrowserModule,
    HttpModule,
    HeadernavModule,
    StoreslistModule.forRoot(),
    PricingModule.forRoot(),
    ProductsModule.forRoot(),
    WebPreviewModule.forRoot(),
    SharedModule,
    CoreModule.forRoot(),
    DataModule.forRoot(),
    AppRoutingModule
  ],
  providers: [HelperService, UtilService, AppLandingService, LocalizationService],
  bootstrap: [AppComponent]
})
export class AppModule { }
