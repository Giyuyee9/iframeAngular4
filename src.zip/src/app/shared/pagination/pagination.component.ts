import { Component, OnInit, OnChanges, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-pagination',
  templateUrl: './pagination.component.html',
  styleUrls: ['./pagination.component.scss']
})
export class PaginationComponent implements OnInit {

  constructor() { }

  @Input() totalRecordsLength: any;
  @Input() pageSize: number;
  @Input() visiablePageCount: number;
  @Input() totalCurrentRecordsLength: number;
  @Output() onPageChange = new EventEmitter();
  pager: any = {};


  ngOnInit() {
    // this.setPage(1);
  }

  ngOnChanges() {
    this.setPage(1);
  }

  setPage(page: number) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    // get pager object
    this.pager = this.getPager(this.pageSize, this.totalRecordsLength, page, this.visiablePageCount);
  }

  getPager(pageSize: number, totalItems: number, currentPage: number = 1, visiablePageCount: number) {
    // calculate total pages
    let totalPages = Math.ceil(totalItems / pageSize);

    let startPage: number, endPage: number;
    if (totalPages <= visiablePageCount) {
      // less than 10 total pages so show all
      startPage = 1;
      endPage = totalPages;
    } else {
      var slot = Math.ceil(currentPage / visiablePageCount);
      startPage = (slot * visiablePageCount) - (visiablePageCount - 1);
      endPage = slot * visiablePageCount;
      if (totalPages < endPage) {
        endPage = totalPages;
      }
    }

    // calculate start and end item indexes
    let startIndex = (currentPage - 1) * pageSize;
    let endIndex = Math.min(startIndex + pageSize - 1, totalItems - 1);
    function range(j, k) {
      return Array
        .apply(null, Array((k - j) + 1))
        .map(function (_, n) { return n + j; });
    }
    var pages = range(startPage, endPage);
    var pageConfigObj = {
      totalItems: totalItems,
      currentPage: currentPage,
      pageSize: pageSize,
      totalPages: totalPages,
      startPage: startPage,
      endPage: endPage,
      startIndex: startIndex,
      endIndex: endIndex,
      pages: pages,
      //totalRecords: 500,
      itemsCount: this.totalCurrentRecordsLength
    };
    this.onPageChange.emit({ pageConfig: pageConfigObj });
    return pageConfigObj;

  }

}
