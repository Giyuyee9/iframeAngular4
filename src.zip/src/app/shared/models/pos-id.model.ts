import {Deserializable} from "./deserializable.model";

export class PosId  implements Deserializable<PosId> {
  id: number;

  deserialize(input: any): PosId {
    Object.assign(this, input);
    return this;
  }
}
