import {Deserializable} from "./deserializable.model";
import {PricingStatus} from "./pricing-status.model";

export class StorePricingStatusDetails implements Deserializable<StorePricingStatusDetails>{

    lobName: string;
    status: number;

    // iPhone?: string;
    // Watch?: string;
    // iPad?: string;
    // Mac?: string;

  deserialize(input: any): StorePricingStatusDetails {
    Object.assign(this, {
      lobName: input.lobName,
      status: this.getPriceStatus(input.status)
    });

    return this;
  }

  getPriceStatus(status) {
    let priceStatus = 1;
    switch (status) {
      case 1:
        priceStatus = PricingStatus.FULLY_PRICED;
        break;
      case 2:
        priceStatus =  PricingStatus.PARTIALLY_PRICED;
        break;
      case 3:
        priceStatus =  PricingStatus.NOT_YET_PRICED;
        break;
      case 4:
        priceStatus =  PricingStatus.NOT_APPLICABLE;
        break;
      default:
        priceStatus =  PricingStatus.NOT_APPLICABLE;
        break;
    }
    return priceStatus;

  }

}
