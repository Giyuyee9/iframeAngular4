import {StoreDetails} from "./store-details.model";
import {Deserializable} from "./deserializable.model";

export class StoreListDetails implements Deserializable<StoreListDetails> {
    storeList: StoreDetails[];

    deserialize(input: any): StoreListDetails {
        Object.assign(this, input);
        this.storeList = input.storeList.map((storeList: StoreDetails) => new StoreDetails().deserialize(storeList));
        return this;
      }
}
