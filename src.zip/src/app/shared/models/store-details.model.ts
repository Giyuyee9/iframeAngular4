import {Deserializable} from "./deserializable.model";
import {StorePricingStatusDetails} from "./store-pricing-status-details.model";

export class StoreDetails implements Deserializable<StoreDetails>{

    posId: string;
    hqId: string;
    storeName: string;
    partnerId: string;
    pricingStatus: StorePricingStatusDetails[];
    city: string;
    country: string;
    isPricingEnable: boolean;
    currency: string;
    tax: number;
    selected: boolean = false;

    deserialize(input: any): StoreDetails {
      Object.assign(this, input);
      return this;
    }

}
