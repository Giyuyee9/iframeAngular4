import {Product} from './product.model';
import {ProductPrice} from './product-price.model';
import {SubLob} from './sublob.model';
import {Deserializable} from "./deserializable.model";

export class ProductPricingDetails implements Deserializable<ProductPricingDetails> {
  product: Product[];
  productPrice: ProductPrice[];
  subLob: SubLob[];

  deserialize(input: any): ProductPricingDetails {
    Object.assign(this, input);
    this.product = input.product.map((product: Product) => new Product().deserialize(product));
    this.productPrice = input.productPrice.map((productPrice: ProductPrice) => new ProductPrice().deserialize(productPrice));
    this.subLob = input.subLob.map((subLob: SubLob) => new SubLob().deserialize(subLob));
    return this;
  }
}
