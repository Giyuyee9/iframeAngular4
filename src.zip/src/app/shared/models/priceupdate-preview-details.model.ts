import { SubLobPricingDetails } from './sub-lob-pricing-details.model';

export class PriceupdatePreviewDetails {
  posId: string;
  posSubLobPricingDetails: SubLobPricingDetails[];
}
