import { Deserializable } from "./deserializable.model";

export class UserInfoDetails implements Deserializable<UserInfoDetails> {
  dsId: string;
  firstName: string;
  lastName: string;

   deserialize(input: any): UserInfoDetails {
    Object.assign(this, input);
    return this;
  }
}
