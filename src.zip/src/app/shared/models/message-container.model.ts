export interface MessageContainer {
  error: string[];
  warning: string[];
  infos: string[];
  hasError: boolean;
  hasWarning: boolean;
  hasInfo: boolean;
}
