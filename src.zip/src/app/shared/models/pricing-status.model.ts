export const PricingStatus = {
    FULLY_PRICED: 1,
	PARTIALLY_PRICED: 2, 
	NOT_YET_PRICED: 3, 
	NOT_APPLICABLE: 4
}