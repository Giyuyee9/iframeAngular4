export interface NotifierModel {
  severity?: string;
  summary?: string;
  detail?: string;
  id?: any;
}
