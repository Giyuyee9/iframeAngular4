import {Deserializable} from "./deserializable.model";

import { MpnItem } from './mpn-item.model';

export class SubLob implements Deserializable<SubLob> {
  id: string;
  description: string;
  hideAssortment: boolean;
  name: string;
  subLobId: string;
  mpnList: MpnItem[];

  deserialize(input: any): SubLob {
    Object.assign(this, input);
    this.subLobId = input.id;
    this.name = input.id;
    this.mpnList = input.mpns.map((mpn: MpnItem) => new MpnItem().deserialize(mpn));
    return this;
  }
}
