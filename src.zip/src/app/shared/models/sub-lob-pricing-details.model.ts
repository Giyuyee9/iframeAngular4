import {Deserializable} from "./deserializable.model";
// import { MpnItem } from './mpn-item.model';
import { ProductPricingDetails } from './product-pricing-details.model';
import { SubLob } from './sublob.model';
import { MpnItem } from './mpn-item.model';
import {Product} from './product.model';

export class SubLobPricingDetails implements Deserializable<SubLobPricingDetails> {
  subLobPriceDetails: SubLob[];
  lobName: string = '';

  deserialize(input: any): SubLobPricingDetails {
    // var mpnList = [];
    // var subLobList = [];
    // var result : any;
    // var subLob: any;
    // var mpnItem: any;
    // //extracting the details from the API response to the correct format
    // var uniqueProducts = [];
    // for(let i = 0; i< input.product.length; i++) {
    //   let product = input.product[i];
    //   //To find the unique object
    //   let obj = uniqueProducts.find(o => o.id === product.subLobId);
    //   //Getting the ProductPrice with the mpn as the key
    //   result = input.productPrice.filter(function(element) {
    //     if (element.mpn == product.mpn) {
    //       return true;
    //     }
    //   });
    //   if(!obj) {
    //     let ll = [{
    //       name: product.mpn,
    //       mpn: product.mpn,
    //       mpnDisplayName: product.mpnDisplayName,
    //       posIds: product.posIds,
    //       subLobId: product.subLobId,
    //       productPrice: result.length!=0? result[0] : null
    //     }];
    //     uniqueProducts.push({
    //       subLobId: product.subLobId,
    //       id: product.subLobId,
    //       name: product.subLobId,
    //       mpnList: [...ll]
    //     });
    //   }
    //   else {
    //     //If already present, then add the mpn to the MPN List
    //     uniqueProducts.map((item) => {
    //       if (item.id === product.subLobId) {
    //         let ll = {
    //           name: product.mpn,
    //           mpn: product.mpn,
    //           mpnDisplayName: product.mpnDisplayName,
    //           posIds: product.posIds,
    //           subLobId: product.subLobId,
    //           productPrice: result.length!=0? result[0] : null
    //         };
    //         item.mpnList.push(ll);
    //       }
    //     });
    //   }
    // }

    this.subLobPriceDetails = input[0].subLobs.map((subLob: SubLob) => new SubLob().deserialize(subLob));
    return this;
  }
}
