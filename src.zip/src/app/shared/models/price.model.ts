import {Deserializable} from "./deserializable.model";

import {PricePlan} from './price-plan.model';

export class Price implements Deserializable<Price> {
  affordability: string;
  appleTC: string;
  geoSpecificLegal: string;
  mpnPartnerName: string;
  otherPricesAvailable: string;
  partnerTC: string;
  partnetPosId: string;
  planName: string;
  supportingCopy: string;
  valueProposition: string;
  pricePlan: PricePlan[];
  deserialize(input: any): Price {
    Object.assign(this, input);
    // this.plan = input.plan.map((plan: PricePlan) => new PricePlan().deserialize(plan));
    return this;
  }

  isEdited: boolean = false;
  private _isModifiedFlag = false;
  isModified(): boolean {
    return this._isModifiedFlag;
  }
  setIsModified(flag) {
    this._isModifiedFlag = flag;
    this.isEdited = flag;
  }
}
