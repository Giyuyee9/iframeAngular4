import {Deserializable} from "./deserializable.model";

export class PricePlan  implements Deserializable<PricePlan> {
  price: number;
  priceOptionName: string;
  priceContractTerm:string;

  deserialize(input: any): PricePlan {
    Object.assign(this, input);
    return this;
  }
}
