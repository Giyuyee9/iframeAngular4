import {Deserializable} from "./deserializable.model";

import {ProductPrice} from './product-price.model';
import {PosId} from "./pos-id.model";
import {MpnLocales} from "./mpn-locales.model";

export class MpnItem implements Deserializable<MpnItem> {
  // id: string = '';
  name: string = '';
  mpn: string = '';
  mpnDisplayName: string = '';
  lob: string;
  hideAssortment: boolean;
  locale: MpnLocales[];
  // posIds: PosId[];
  posIds = [];
  subLobId: string = '';
  imagePath: string;
  isAccessory: boolean;
  mpnAttribute: any[];
  productPrice: ProductPrice;

  deserialize(input: any): MpnItem {
    Object.assign(this, input);
    this.locale = input.locale.map((locales: MpnLocales) => new MpnLocales().deserialize(locales));
    return this;
  }
}
