import {Deserializable} from "./deserializable.model";
import {MessageContainer} from './message-container.model';
import {StoreListDetails} from './storelist-details.model';

export class StoreDetailsWrapper implements Deserializable<StoreDetailsWrapper> {
  messageContainer: MessageContainer;
  content: {
    storePricingList: StoreListDetails;
  };

  deserialize(input: any): StoreDetailsWrapper {
    Object.assign(this, input);
    return this;
  }
}
