import {Deserializable} from "./deserializable.model";

import { SubLob } from './sublob.model';

export class Lob implements Deserializable<Lob> {
  id: string;
  name: string;
  sublobList: SubLob[];

  deserialize(input: any): Lob {
    Object.assign(this, input);
    return this;
  }
}
