import {Deserializable} from "./deserializable.model";

export class ProductList implements Deserializable<ProductList> {
  lob: string;
  subLob: string[];
  selected: boolean = false;

  deserialize(input: any): ProductList {
    Object.assign(this, input);
    return this;
  }
}
