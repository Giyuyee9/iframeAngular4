export interface ActionStatus {
  severity: string;
  message: string;
  closeModal: boolean;
}
