import {PosId} from "./pos-id.model";
import {Deserializable} from "./deserializable.model";

export class Product implements Deserializable<Product> {
  mpn: string;
  mpnDisplayName: string;
  posIds: PosId[];
  subLobId: string;
  name: string;
  deserialize(input: any): Product {
    Object.assign(this, input);
    this.posIds = input.posIds.map((posIds: PosId) => new PosId().deserialize(posIds));
    return this;
  }
}
