import {Deserializable} from "./deserializable.model";

export class MpnLocales implements Deserializable<MpnLocales> {
  locale: string;
  mpnDesc: string;
  deserialize(input: any): MpnLocales {
    Object.assign(this, input);
    this.locale = input.Locale;
    return this;
  }
}
