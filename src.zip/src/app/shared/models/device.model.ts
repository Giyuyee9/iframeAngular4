import {Deserializable} from "./deserializable.model";

export class Device implements Deserializable<Device>{
    id: number;
    name:string; 
    weblink: string;

    deserialize(input: any): Device {
        Object.assign(this, input);
        return this;
      }
}
