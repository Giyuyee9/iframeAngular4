import {Deserializable} from "./deserializable.model";

import {PricePlan} from './price-plan.model';
import {Price} from './price.model';

export class ProductPrice implements Deserializable<ProductPrice> {
  posId: string;
  mpn: string;
  // affordability: string;
  // appleTC: string;
  // geoSpecificLegal: string;
  // mpnPartnerName: string;
  // otherPricesAvailable: string;
  // partnerTC: string;
  // partnetPosId: string;
  // planName: string;
  // supportingCopy: string;
  // valueProposition: string;
  // plan: PricePlan[];
  price: Price;
  deserialize(input: any): ProductPrice {
    Object.assign(this, input);
    // this.plan = input.plan.map((plan: PricePlan) => new PricePlan().deserialize(plan));
    return this;
  }
}
