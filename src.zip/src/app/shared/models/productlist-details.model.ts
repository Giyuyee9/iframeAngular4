import {Deserializable} from "./deserializable.model";
import {ProductList} from './product-list.model';

export class ProductlistDetails implements Deserializable<ProductlistDetails> {
  lobList: ProductList[];
  selectedLobItem: string = "";

  deserialize(input: any): ProductlistDetails {
    Object.assign(this, input);
    this.lobList = input.map((item: ProductList) => new ProductList().deserialize(item));
    return this;
  }
}
