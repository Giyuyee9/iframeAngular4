import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PaginationComponent } from './pagination/pagination.component';


import {SubHeaderComponent} from './sub-header/sub-header.component';
import { LocalizePipe } from '../common/loc.pipe';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [SubHeaderComponent, LocalizePipe, PaginationComponent],
  exports: [SubHeaderComponent, LocalizePipe, PaginationComponent]
})
export class SharedModule { }
