import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormArray, NgForm } from '@angular/forms';
import { LobListService } from '../lob-list.service';
import { ProductList } from '../../shared/models/product-list.model';

@Component({
  selector: 'app-web-preview-search',
  templateUrl: './web-preview-search.component.html',
  styleUrls: ['./web-preview-search.component.scss']
})
export class WebPreviewSearchComponent implements OnInit {
  phones: Array<string> = [];
  @Input() currsearchContent: any;
  @Input() currselectedPhone: any;
  @Input() currLocale: any;
  @Output() onSearchText = new EventEmitter();
  @Output() onupdateSearchParams = new EventEmitter();

  lobList: ProductList[];
  selectedLob: string;
  constructor(private lobListService: LobListService) {

  }

  ngOnInit() {
  }

  searchText() {
    this.onSearchText.emit()
  }

  onAppleIdChange($event) {
    this.currselectedPhone = '';
    this.invokeupdateSearch();
    this.phones = null;
    this.selectedLob = null;
    if ($event.length > 3) {
      this.lobListService.fetchPhoneList([$event]).subscribe((productListDetails: any) => {
        if (productListDetails) {
          this.phones = productListDetails.subLob;
          this.selectedLob = productListDetails.lob;
        } else {
          this.phones = null;
          this.selectedLob = null;
        }
      });
    }
  }

  invokeupdateSearch() {
    this.onupdateSearchParams.emit({ 'selectedLob': this.selectedLob, 'searchContent': this.currsearchContent, 'selectedPhone': this.currselectedPhone, 'locale': this.currLocale })
  }
}
