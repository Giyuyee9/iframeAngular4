import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import { Http, Response } from '@angular/http';
import { Device } from '../shared/models/device.model';
import {environment} from '../../environments/environment';



import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/do';

@Injectable()
export class DeviceService {
    protected devices = new Subject();
  devices$ = this.devices.asObservable();
  //devicesUrl: string = 'assets/api/devices.json';

  //url for while using api
  devicesUrl: string = environment.devicesAPIUrl;

  constructor(private http: Http) { }

    searchDevice(appleId:string, lob: string, sublob: string, locale: string): void {
        // this.devices.next({'weblink':this.devicesUrl + '?locale=' + 'en_US' + '&lob=' + lob + '&appleId=' + appleId});
        //stores/12354/locales/en_US/lobs/iPhone
        const url = `${this.devicesUrl}stores/${appleId}/locales/${locale}/lobs/${lob}/sublob/${sublob}`;
        this.http.get(url)
            .map(res => res.json())
            .map(res => res).subscribe(
            (response: any) => {
                this.devices.next(response);
            },
            (error: Error) => {
            this.devices.next(undefined);
            }
        );

    }
}
