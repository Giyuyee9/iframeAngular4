import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import {WebPreviewDeviceComponent} from './web-preview-device/web-preview-device.component';
import {WebPreviewSearchComponent} from './web-preview-search/web-preview-search.component';

const routes: Routes = [
  {path: 'preview', component: WebPreviewDeviceComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class WebPreviewRoutingModule { }
export const routedComponents = [WebPreviewDeviceComponent, WebPreviewSearchComponent];
