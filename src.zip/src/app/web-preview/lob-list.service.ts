import { Injectable } from '@angular/core';
import { RequestOptions, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { HttpAuthService } from '../core/http-auth.service';
import { ProductlistDetails } from '../shared/models/productlist-details.model';
import { environment } from '../../environments/environment';

@Injectable()
export class LobListService {

  lobListAPIUrl: string;

  constructor(private http: HttpAuthService) { }

  fetchPhoneList(posIds: string[]): Observable<any> {
    this.lobListAPIUrl = environment.getLobListAPIUrl;
    return this.http.post(this.lobListAPIUrl, { posIds })
      .map((res: Response) => res.json())
      .map((res: any) => {
        let iphoneloblist;
        new ProductlistDetails().deserialize(res.lobList).lobList.forEach((val, index) => {
          if (val.lob.toLowerCase() == 'iphone') iphoneloblist = val;
        })
        //Here we are return only the loblist of iPhone
        return iphoneloblist;
      })
      .catch((error: any) => {
        debugger;
        return Observable.throw(error);
      });
  }
}
