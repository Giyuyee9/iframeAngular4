import { NgModule, ModuleWithProviders} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {HttpModule} from '@angular/http';
import { SafePipe } from '../common/safe.pipe'

import { WebPreviewRoutingModule, routedComponents} from './web-preview-routing.module';
import { ListboxitemModule } from 'pricingweb-uicomponents';
import { DeviceService } from './devices.service';
import { LobListService } from './lob-list.service';
import {SharedModule} from '../shared/shared.module';

@NgModule({
  imports: [
    CommonModule,
    WebPreviewRoutingModule,
    ListboxitemModule,
    SharedModule,
    FormsModule,
    HttpModule
  ],
  declarations: [routedComponents, SafePipe]
})
export class WebPreviewModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: WebPreviewModule,
      providers: [DeviceService, LobListService]

    };
  }
}
