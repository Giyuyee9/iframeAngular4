import { Component } from '@angular/core';
import { DeviceService } from '../devices.service';
import { FormGroup, FormControl, FormArray, NgForm } from '@angular/forms';

@Component({
  selector: 'app-web-preview-device',
  templateUrl: './web-preview-device.component.html',
  styleUrls: ['./web-preview-device.component.scss']
})
export class WebPreviewDeviceComponent {
  searchContent: string;
  selectedPhone: string = '';
  locale: string = 'en_US';
  showIframe: Boolean = false;
  phoneContent: any;
  weblink: string;
  selectedLob: string;

  constructor(public deviceService: DeviceService) {
    this.deviceService.devices$.subscribe((resp) => {
      this.weblink = (resp as any).previewURL;
      this.showIframe = true;
    });
  }

  searchText($event) {
    if (this.searchContent && this.searchContent.length > 0) {
      this.deviceService.searchDevice(this.searchContent, this.selectedLob, this.selectedPhone, this.locale);
      //this.deviceService.searchDevice(this.searchContent, this.selectedPhone, this.locale);
    }
  }
  updateSearchParams(data) {
    this.searchContent = data.searchContent;
    this.selectedPhone = data.selectedPhone;
    this.locale = data.locale;
    this.selectedLob = data.selectedLob && data.selectedLob.toLowerCase();
    this.weblink = null;
  }
}
