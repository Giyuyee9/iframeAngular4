import { Injectable } from '@angular/core';
import {Http, RequestOptionsArgs, Headers} from '@angular/http';
import {Observable} from 'rxjs/Observable';

import { HelperService } from '../common/services/helper.service';
// import { EmitterService } from './emitter.service';
import {Router} from '@angular/router';

import 'rxjs/add/observable/of';

@Injectable()
export class HttpAuthService {

  constructor(private http: Http,
              private router: Router,
              private _helper: HelperService) { }

  // public headers: Object = {};

  /**
   * Setting headers
   * @param options
   * @returns {any}
   */
  setHeaders(options) {
    options = options || {};
    options.headers = options.headers || new Headers();
    // Append headers
    const sessionId = '12345';
    if (sessionId) {
      options.headers.append('sessionId', sessionId);
    }
    // Append some default header for all the API calls from client Side
    options.headers.append('req-from-api', 'true');
    return options;
  }

  catchCallback(res) {
    if (res.status === 500) {
      //
      console.log('The is some internal server error');
      // this.router.navigate(['/' + 'not-found']);
    } else if (res.status === 403) {
      // this.redirectLogin();
    } else if (res.status === 405) {
      //
    } else if (res.status === 401) {
      // const body = JSON.parse(res._body);
      // const e = body.errorInfo;
      if (res.headers.get('redirectUrl')) {
        // redirect tpo the new URL
        window.location.href = res.headers.get('redirectUrl');
      } else {
        // redirect to logout
        console.log('in the catch block before the redirection');
        window.location.href = 'http://mystore-mdn-lx-ws.corp.apple.com:4774/logout';
      }
      return;
    }
    return Observable.of(res);
  }

  get(url: string, options?: RequestOptionsArgs, localNotification?: boolean): Observable<Response> {
    options = this.setHeaders(options);
    const isLocalNotification = localNotification;
    return this.http.get(url, options)
      .map((res) => {
        if (this._helper.checkForRedirect(url, res.url)) {
          this._helper.storeDataForRedirect(res.json(), res.url);
        }
        if (!isLocalNotification) {
           this._checkForNotificationAlert(res.json());
        };
        return res;
      })
      .catch(res => this.catchCallback(res));
  }


  post(url: string, data: any, options?: RequestOptionsArgs, localNotification?: boolean): Observable<Response> {
    options = this.setHeaders(options);
    const isLocalNotification = localNotification;
    return this.http.post(url, data, options)
    .map((res) => {
      if (this._helper.checkForRedirect(url, res.url)) {
        this._helper.storeDataForRedirect(res.json(), res.url);
      }
      if (!isLocalNotification) {
        this._checkForNotificationAlert(res.json());
      }
      return res;
    })
    .catch(res => this.catchCallback(res));
  }

  put(url: string, data: any, options?: RequestOptionsArgs, localNotification?: boolean): Observable<Response> {
    options = this.setHeaders(options);
    const isLocalNotification = localNotification;
    return this.http.put(url, data, options)
    .map((res) => {
      if (this._helper.checkForRedirect(url, res.url)) {
        this._helper.storeDataForRedirect(res.json(), res.url);
      }
      if (!isLocalNotification) {
        this._checkForNotificationAlert(res.json());
      }
      return res;
    })
    .catch(res => this.catchCallback(res));
  }
  _checkForNotificationAlert(resp) {
    if (resp.messageContainer) {
      if (resp.messageContainer.hasError) {
        // this._emitter.publishNotify({severity: 'error', detail: resp.messageContainer.errors[0].description});
      } else if (resp.messageContainer.hasWarning) {
        // this._emitter.publishNotify({severity: 'warn', detail: resp.messageContainer.warnings[0].description});
      } else if (resp.messageContainer.hasInfo) {
        // this._emitter.publishNotify({severity: 'info', detail: resp.messageContainer.infos[0].description});
      }
    }
  }

}
