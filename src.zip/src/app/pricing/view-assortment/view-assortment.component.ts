import { Component, OnInit, Input, Output, EventEmitter, OnChanges } from '@angular/core';

import { SubLob } from '../../shared/models/sublob.model';
@Component({
  selector: 'app-view-assortment',
  templateUrl: './view-assortment.component.html',
  styleUrls: ['./view-assortment.component.scss']
})
export class ViewAssortmentComponent implements OnInit {

  @Input() lobList: any;
  @Input() subLobListItem: any;
  @Input() selLobItem: any;
  @Input() taxStatus: any;
  @Output() onToggleChange: EventEmitter<any> = new EventEmitter<any>();
  subLobs = [];

  constructor() { }

  ngOnInit() {
  }

  ngOnChanges() {
    this.subLobs = this.subLobListItem.subLobPriceDetails;
  }

  changeStatus(item, toggleEvent) {
    console.log(toggleEvent);
    item.toggle = toggleEvent.value;
    this.onToggleChange.emit(item);
    // toggleEvent.event.stopPropagation();
  }

}
