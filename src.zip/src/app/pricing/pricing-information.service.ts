import { Injectable } from '@angular/core';
import {RequestOptions, Headers} from '@angular/http';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

import {HttpAuthService} from '../core/http-auth.service';
import {ProductPricingDetails} from '../shared/models/product-pricing-details.model';
import {SubLobPricingDetails} from '../shared/models/sub-lob-pricing-details.model';

import { environment } from '../../environments/environment';
import { ActionStatus } from '../shared/models/actionStatus.model';

@Injectable()
export class PricingInformationService {

  constructor(private http: HttpAuthService) { }
  private productPricingAPIUrl = '';
  private hideAssortmentAPIUrl = '';

  fetchProductPricing(posIds: string[], lob: string): Observable<SubLobPricingDetails> {
     // this.productPricingAPIUrl = '/assets/api/productPricingDetails.json';
     // return this.http.get(this.productPricingAPIUrl)
     this.productPricingAPIUrl = environment.getProductPricingAPIUrl;
     return this.http.post(this.productPricingAPIUrl, { posIds: posIds, lob: lob})
     .map((res: Response) => res.json())
     .map((res => new SubLobPricingDetails().deserialize(res)))
     // .map((res: Response) => res.json().response.map((user: ProductPricingDetails) => new ProductPricingDetails().deserialize(user)));

      // .map(res => res.json())
      // .catch((error: any) => Observable.throw(error.json().error));
      // .map(res => res.json())
      .catch((error: any) => Observable.throw(error.json()));
  }

  saveProductPricing(body: any): any {
    // const updateUrl = environment.saveProductPricingAPIUrl;
    // const headers = new Headers({ 'Content-Type': 'application/json'});
    // const options = new RequestOptions({
    //   headers: headers
    // });
    // return this.http.put(updateUrl, body, options, true).map(rsp => rsp.json());

  }

  toggle(assortmentDetails :any) {
    this.hideAssortmentAPIUrl = environment.hideAssortmentAPIUrl;
    return this.http.post(this.hideAssortmentAPIUrl, assortmentDetails)
      .map((res: Response) => res.json())
      // .map((res => new SubLobPricingDetails().deserialize(res)))
      .catch((error: any) => Observable.throw(error.json()));
  }

  displayNotification(respData): ActionStatus {
    let actionStatus: ActionStatus;
    // if ('messageContainer' in respData && respData.messageContainer) {
    //   if (respData.messageContainer.hasError) {
    //     actionStatus = { severity: 'error', message: respData.messageContainer.errors[0].description, closeModal: false };
    //   } else if (respData.messageContainer.hasWarning) {
    //     actionStatus = { severity: 'warn', message: respData.messageContainer.warnings[0].description, closeModal: false };
    //   } else if (respData.messageContainer.hasInfo) {
    //     actionStatus = { severity: 'info', message: respData.messageContainer.infos[0].description, closeModal: false };
    //   }
    // }
    // if (respData.status === 'Success') {
        actionStatus =  { severity: 'success', message: 'Price Updated Successfully!!!', closeModal: true };
    // }
    return actionStatus;
  }


}
