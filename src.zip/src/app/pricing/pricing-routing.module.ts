import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ViewPricingComponent } from './view-pricing/view-pricing.component';
import { PricingMainComponent } from './pricing-main/pricing-main.component';
import { ViewAssortmentComponent } from './view-assortment/view-assortment.component';

const routes: Routes = [
  {path: 'viewpricing', component: PricingMainComponent},
  {path: 'viewassortment', component: ViewAssortmentComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PricingRoutingModule { }
export const routedComponents = [ViewPricingComponent, PricingMainComponent, ViewAssortmentComponent];
