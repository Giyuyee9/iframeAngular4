import { Component, OnInit, Input, OnChanges } from '@angular/core';

import { SubLob } from '../../shared/models/sublob.model';

@Component({
  selector: 'app-view-pricing',
  templateUrl: './view-pricing.component.html',
  styleUrls: ['./view-pricing.component.scss']
})
export class ViewPricingComponent implements OnInit, OnChanges {

  constructor() { }

  @Input() lobList: any;
  @Input() subLobListItem: any;
  @Input() selLobItem: any;
  @Input() taxStatus: any;
  subLobs = [];

  ngOnInit() {

  }

  ngOnChanges() {
    this.subLobs = this.subLobListItem.subLobPriceDetails;
  }



}
