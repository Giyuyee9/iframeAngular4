import { Component, OnInit, OnDestroy } from '@angular/core';
//import {EmitterService} from "../../shared/emitter.service";
//import {HelperService} from "../../common/services/helper.service";
import {Router} from '@angular/router';
import {Subscription} from 'rxjs/Subscription';
import {PricingInformationService} from '../pricing-information.service';
import {ProductPricingDetails} from '../../shared/models/product-pricing-details.model';
import {SubLobPricingDetails} from '../../shared/models/sub-lob-pricing-details.model';
import { FormDataService } from '../../data/form-data.service';
import {StoreListDetails} from '../../shared/models/storelist-details.model';
import {StoreDetails} from '../../shared/models/store-details.model';
import { ProductlistDetails } from '../../shared/models/productlist-details.model';

@Component({
  selector: 'app-pricing-main',
  templateUrl: './pricing-main.component.html',
  styleUrls: ['./pricing-main.component.scss']
})
export class PricingMainComponent implements OnInit, OnDestroy {

  loading = true;
  storeListContent: {};
  private viewSubscription: Subscription;
  productPriceDetails: SubLobPricingDetails;
  currentWorkflow: string;
  nextStep: string;
  selectedStores: StoreListDetails;
  selectedStoresList: StoreDetails[] =[];
  selectedStoreDetails: StoreDetails;
  storeWorkFlow: boolean = false;
  taxStatus: number;
  selectedProductList: ProductlistDetails;
  selectedLob: string;
  // subLobLists : any[];
  // prodListDetails: SubLobPricingDetails;

  constructor(private _router: Router,
              private pricingService: PricingInformationService,
              private formDataService: FormDataService) { }

  ngOnInit() {

    this.productPriceDetails = this.formDataService.getSubLobPricingDetails();
    this.selectedStores = this.formDataService.getSelectedStoreListDetails();
    this.currentWorkflow = this.formDataService.getWorkFlowSelection();
    this.selectedProductList = this.formDataService.getProductsListDetails();
    let posIds = [];
    if(this.selectedStores) {
      this.selectedStoreDetails = this.selectedStores.storeList[0];
      this.taxStatus = this.selectedStores.storeList[0].tax;
      this.selectedLob = this.selectedProductList.selectedLobItem;
      if (this.selectedStores.storeList.length > 0) {
        this.selectedStores.storeList.map((item) => {
        posIds.push(item.posId);
        });
      }
    }
    else {
      this._router.navigate(['/storeslist']);
    }
    console.log(this.selectedStoresList);
        // console.log('Personal feature loaded!');
    if (this.productPriceDetails &&
        this.productPriceDetails.lobName &&
        this.productPriceDetails.subLobPriceDetails &&
        this.productPriceDetails.subLobPriceDetails) {

      console.log(this.productPriceDetails);
      // this.productPriceDetails = priceDetails;
      this._setDataForView(this.productPriceDetails);
      this.loading = false;
    }
    else {

      this.viewSubscription = this.pricingService.fetchProductPricing(posIds, this.selectedLob).subscribe((priceDetails: SubLobPricingDetails) => {
        console.log(priceDetails);
        // this.productPriceDetails = priceDetails;
        this._setDataForView(priceDetails);
        this.loading = false;
      });
    }
    //Display the store list in the case of Store Workflow
    // if (this.currentWorkflow === WORKFLOWS.Store) {

      // this.selectedStores = selectedStoreList.storeList;
    // }

  }

  private _setDataForView(viewData: SubLobPricingDetails): void {
    if (viewData) {
        // console.log(viewData);
      this.productPriceDetails = viewData;
    }
  }

  ngOnDestroy() {
    if ( this.viewSubscription ) {
      this.viewSubscription.unsubscribe();
    }
  }

  onToggleChange(assortmentDetails:any){
    console.log("assortmentDetails :"+assortmentDetails);
    let data = {
      "posId": [],
      "hqId": this.selectedStores.storeList[0].hqId,
      "timestamp": new Date(),
      "status": assortmentDetails.toggle,
      "hideDetails": [{
        "lob": this.selectedLob,
        "subLob": assortmentDetails.subLobId,
        "mpn": assortmentDetails.mpn || ""
      }]
    };
    if( !!assortmentDetails.posIds ) {
      data.posId = assortmentDetails.posIds;
    } else {
      this.selectedStores.storeList.forEach( item => {
        data.posId.push(item.posId);
      });
    }
    this.pricingService.toggle(data).subscribe((res: any) => {});
  }

  onSaveProductPrice(priceUpdateDataForm: any) {
    // this.data = JSON.stringify(priceUpdateData);
    if(this.save(priceUpdateDataForm)) {
      // this._router.navigate(['/preview']);
      // let currentWorkflowName = this.formDataService.getWorkFlowSelection();
      // let nextStep = this.workflowService.getNextWorkFlowStepFromRoute(this._router.url, currentWorkflowName);
      console.log(this.nextStep);
      this._router.navigate(['/'+ this.nextStep]);
    }
    // this.pricingService.saveProductPricing(data).subscribe((data: any) => {
    //   this.loading = false;
    // });
  }
  save(priceUpdateDataForm: any): boolean {
      // if (!priceUpdateDataForm.form.valid) {
      //   return false;
      // }
      this.formDataService.setSubLobPricingDetails(priceUpdateDataForm);
      return true;
  }
}
