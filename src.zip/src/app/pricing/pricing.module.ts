import { NgModule, ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PricingRoutingModule, routedComponents } from './pricing-routing.module';

import { PricingInformationService } from './pricing-information.service';
import { TableviewModule, HeadernavModule, ToggleButtonModule } from 'pricingweb-uicomponents';
import {SharedModule} from '../shared/shared.module';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    PricingRoutingModule,
    TableviewModule,
    HeadernavModule,
    ToggleButtonModule,
  ],
  declarations: [routedComponents],
  exports: [routedComponents]
})

export class PricingModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: PricingModule,
      providers: [PricingInformationService]

    };
  }
}
