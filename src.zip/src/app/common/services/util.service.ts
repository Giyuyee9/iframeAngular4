import { Injectable } from '@angular/core';

@Injectable()
export class UtilService {

  constructor() { }

  sortAscending(list :any[], colName: string):any[]  {
    list.sort( function(a:any, b:any) {
      if (isNaN(a[colName]) || isNaN(b[colName])) {
        return a[colName] > b[colName] ? 1 : -1;
      }
      return a[colName] - b[colName];
    });
    return list;
  }
  sortDescending(list :any[], colName: string):any[] {
    list.sort( function(a:any, b:any) {
      if (isNaN(a[colName]) || isNaN(b[colName])) {
        return a[colName] < b[colName] ? 1 : -1;
      }
      return b[colName] - a[colName];
    });
    return list;
  }
  sortByColumn( list:any[], order:boolean, colName:string):any[] {
    if( order ) {
      return this.sortAscending( list, colName);
    } else {
      return this.sortDescending( list, colName);
    }
  }

}
