import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';

// import { StoreInfo } from '../common/models/storeInfo';
import { NotifierModel } from '../../shared/models/notifier.model';

@Injectable()
export class EmitterService {

    // private selectedStore = new Subject<StoreInfo>();
    // public selectedStore$ = this.selectedStore.asObservable();

    // private storeAsQuickLink = new Subject<StoreInfo>();
    // public storeAsQuickLink$ = this.storeAsQuickLink.asObservable();

    private saveReload = new Subject<boolean>();
    public saveReload$ = this.saveReload.asObservable();

    private notify = new Subject<NotifierModel>();
    public notify$ = this.notify.asObservable();

    private closeModal = new Subject<boolean>();
    public closeModal$ = this.closeModal.asObservable();

    constructor() { }

    // publishCurrentSelectedStore(currSelectedStore: StoreInfo) {
    //   this.selectedStore.next(currSelectedStore);
    // }

    publishSaveReload(saveStatus: boolean) {
      this.saveReload.next(saveStatus);
    }

    // publishStoreAsQuickLink(prevSelectedStore: StoreInfo) {
    //   this.storeAsQuickLink.next(prevSelectedStore);
    // }

    publishNotify(message: NotifierModel) {
      this.notify.next(message);
    }

    publishCloseModal(modalClosed: boolean) {
      this.closeModal.next(modalClosed);
    }
}
