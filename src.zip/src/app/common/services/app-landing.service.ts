import {Injectable} from '@angular/core';
import 'rxjs/add/operator/toPromise';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

import { HttpAuthService } from '../../core/http-auth.service';
import { environment } from '../../../environments/environment';

@Injectable()
export class AppLandingService {

  constructor(private http: HttpAuthService) { }

  getLocalizationDetails() {
    return this.http.get('assets/api/localization.json')
      .map((res:Response) => res.json());
  }

  logout() {
    return this.http.get('').subscribe(data => {
      return data;
    });
  }
}
