import { Injectable } from '@angular/core';

export const PATH_NAME_REGEX = /^[^#]*?:\/\/.*?(\/.*)$/;

@Injectable()
export class HelperService {

  public dataForRedirectView: any;
  public redirectPath: string;
  public respPathName: string;
  public isRedirect: boolean;

  constructor() { }

   checkForRedirect(reqURL: string, respURL: string): boolean {
    const respPathName = PATH_NAME_REGEX.exec(respURL)[1];
    return reqURL !== respPathName;
  }

  storeDataForRedirect(respBody: any, respURL: string): void {
    this.dataForRedirectView = respBody;
    this.redirectPath = this._findNewPath(respURL);
    this.respPathName = PATH_NAME_REGEX.exec(respURL)[1];
    this.isRedirect = true;
  }

  resetRedirectData(): void {
    this.dataForRedirectView = null;
    this.redirectPath = null;
    // this.respPathName = null;
    this.isRedirect = false;
  }

 _findNewPath(uri: string): string {
    return uri.substring(uri.lastIndexOf('/'));
  }

}
