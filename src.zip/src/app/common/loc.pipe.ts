import { Pipe, PipeTransform } from '@angular/core';
import {DomSanitizer} from '@angular/platform-browser';

import {LocalizationService} from '../data/localization.service';

@Pipe({
  name: 'loc'
})
export class LocalizePipe implements PipeTransform {
  constructor(private locale: LocalizationService) {}
  transform(key) {
    return this.locale.data[key];
  }
}
