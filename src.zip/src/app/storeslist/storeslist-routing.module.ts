import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { StoreListMainComponent } from './store-list-main/store-list-main.component';
import { StoreListComponent } from './store-list/store-list.component';

const routes: Routes = [
  {path: 'storeslist', component: StoreListMainComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class StoreslistRoutingModule { }
export const routedComponents = [StoreListMainComponent, StoreListComponent];
