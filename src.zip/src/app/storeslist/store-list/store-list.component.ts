import {Component, OnInit, Input, Output, OnChanges, EventEmitter} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import { UtilService } from '../../common/services/util.service';

import {StoreDetails} from "../../shared/models/store-details.model";
import {PricingStatus} from "../../shared/models/pricing-status.model";
import { environment } from "../../../environments/environment"

@Component({
  selector: 'app-store-list',
  templateUrl: './store-list.component.html',
  styleUrls: ['./store-list.component.scss']
})
export class StoreListComponent implements OnInit {

  ListViewRecords: StoreDetails[];
  loading = true;
  selected_id: string;
  selectedStoreListDetails = [];
  selectAllCheckbox = true;
  pricingStatusList = PricingStatus;
  environment = environment;

  @Input() currStoreListContent: any;
  @Input() totalStoreListRecordsCount: number;
  @Input() storeListCount: number;
  @Output() onPricingStatusToggle = new EventEmitter();
  @Output() onSelectedStoreRow = new EventEmitter();
  @Output() onSelectAllStoreList = new EventEmitter();
  @Output() onSelectedCellClick = new EventEmitter();
  @Output() filterChanged: EventEmitter<any> = new EventEmitter<any>();
  @Output() onPaginationChange: EventEmitter<any> = new EventEmitter<any>();

  constructor(private _router: Router, private _activatedRoute: ActivatedRoute, private utilService:UtilService) { }

  ngOnInit() {
  }

  ngOnChanges() {
    if ( this.currStoreListContent ) {
      this.ListViewRecords = this.currStoreListContent;
      this.loading = false;
      this.ListViewRecords.map((item) => {
        if(!item.selected){
          this.selectAllCheckbox = false;
          return false;
        }
      });
    }
  }

  onSelectAll(selected) {
    this.ListViewRecords.map((item) => {
      item.selected = selected;
      return item;
    });
    this.selectAllStoreListEvent(this.ListViewRecords, selected);
  }

  onSelectRow(item) {
    item.selected = !item.selected;
    if (!item.selected) {
      this.selectAllCheckbox = false;
    }
    this.selectedStoreEvent(item);

  }

  selectedStoreEvent(item: any) {
    this.onSelectedStoreRow.emit(item);
  }
  selectAllStoreListEvent(items: any, selected: boolean) {
    this.onSelectAllStoreList.emit({ items: items, selected: selected });
  }

  changePricingStatus(item, value) {
    console.log('test', value, item);
    this.onPricingStatusToggle.emit({item,value});
  }

  onCellClickedEvent(rowEvent: any) {
    console.log(rowEvent.row.item);
    rowEvent.row.item.selected = true;
    // this.selectedStoreEvent(rowEvent.row.item);
    this.onSelectedCellClick.emit({ items: rowEvent.row.item, selected: true });
  }

  onSearchType($event: any): void {
    if (($event.target.value.trim() !== '' && $event.target.value.length >= 3)) {
      this.loading = true;
      this.filterChanged.emit($event);
    }
  }

  onPageChangeHandle($event) {
    // table loading spinner is not required for page 1
    if( $event.pageConfig.currentPage != 1 ) {
      // this.loading = true;
    };
    this.onPaginationChange.emit($event);
  }
  onSortColumn($event):void{
    this.ListViewRecords = this.utilService.sortByColumn(this.ListViewRecords, $event.params.sortAsc , $event.column.property);
  }
}
