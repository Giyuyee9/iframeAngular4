import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StoreListMainComponent } from './store-list-main.component';

describe('StoreListMainComponent', () => {
  let component: StoreListMainComponent;
  let fixture: ComponentFixture<StoreListMainComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StoreListMainComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StoreListMainComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
