import {Component, OnInit, Input, OnDestroy} from '@angular/core';
import {Router} from '@angular/router';
import {Subscription} from 'rxjs/Subscription';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';

import { StoreslistService } from '../storeslist.service';
import {StoreDetails} from "../../shared/models/store-details.model";
import {StoreListDetails} from "../../shared/models/storelist-details.model";
import { FormDataService } from '../../data/form-data.service';
import { environment } from "../../../environments/environment"


@Component({
  selector: 'app-store-list-main',
  templateUrl: './store-list-main.component.html',
  styleUrls: ['./store-list-main.component.scss']
})
export class StoreListMainComponent implements OnInit, OnDestroy {

  loading = true;
  storeListTotalContent: {};
  private viewSubscription: Subscription;
  selectedStoreListDetails = [];
  pager: any = {};
  allItems: any[];
  pagedItems: any[];
  environment = environment;
  currentStoreListContent: any[];
  pagination: any = {};
  storeList$ = new Subject<any[]>();
  searchTerm$ = new Subject<string>();

  constructor(private _router: Router,
              private storeService: StoreslistService,
              private formDataService: FormDataService) { }

  ngOnInit() {
    this.viewSubscription = this.storeService.fetchStoreList(this._router.url, { "currentPage": "1", "pageSize": "10", "contains": "" }).subscribe((storeList: StoreListDetails) => {
    console.log('called');
      this._setDataForView(storeList, this._router.url);
    });
    this.loading = false;

    this.storeList$.subscribe((item) => {
      console.log(item);
    });

    this.search(this.searchTerm$).subscribe((storeList: StoreListDetails) => {
      console.log("results", storeList);
      this.loading = false;
      this._setDataForView(storeList, this._router.url);
    });
  }

  private _setDataForView(viewData: any, routePath: string): void {
    if (viewData) {
      this.storeListTotalContent = {
        storeList: viewData.storeList,
        // :TODO Remove later
        storePricingContent: {
          pagination: {
            currentPage: 1,
            pageSize: 10,
            totalCount: viewData.storeList.length
          },
          storePricingList: viewData.storeList
        }
      };
      // this.totalStoreList = viewData["storePricingContent"].storePricingList;
      // this.setCurrentstoreListTotalContent(0, this.environment.storeListTablePageSize-1);
      this.pagination =  this.storeListTotalContent["storePricingContent"].pagination;
      this.setCurrentStoreListContent(0, this.environment.storeListTablePageSize-1);
      // this.pagination = viewData["storePricingContent"].pagination;
      this.loading = false;
    }
  }

  onFilterChanged($event) {
    console.log("search :", $event.target.value);
    this.searchTerm$.next($event.target.value);
  }
  doSearch($event) {
    console.log("search :", $event.target.value);
     this.searchTerm$.next($event.target.value);
  }

  search(terms: Observable<string>) {
    return terms.debounceTime(400)
      .distinctUntilChanged()
      .switchMap((term) => {
        // this.loading = true;
        return this.storeService.fetchStoreList(this._router.url, { "currentPage": "1", "pageSize": "10", "contains": term })
    });
  }

  ngOnDestroy() {
    if ( this.viewSubscription ) {
      this.viewSubscription.unsubscribe();
    }
  }

  navigateToPricing() {
    if (this.selectedStoreListDetails.length > 0) {
      this.formDataService.setSelectedStoreListDetails(this.selectedStoreListDetails);
      this._router.navigate(['/productlist']);
    }
  }
  navigateToPricingWithStoreId($event) {
    this.selectedStoreListDetails = [];
    if ($event.selected) {
      this.selectedStoreListDetails.push($event.items);
    }
   this.navigateToPricing();
  }
  handlePricingStatusToggle($event){

  }

  handleOnSelectedStoreRow(rowEventItem){
    if (rowEventItem.selected === true) {
      this.selectedStoreListDetails.push(rowEventItem);
    } else {
      const index = this.selectedStoreListDetails.findIndex(row => row.posId === rowEventItem.posId);
      this.selectedStoreListDetails.splice(index, 1);
    }
    // this.selectedStoreListDetails.push(rowEventItem.row.item);
    // console.log(this.selectedStoreListDetails);
    // this.navigateToPricing();
    this.storeList$.next(this.selectedStoreListDetails);
  }

  handleOnSelectAllStoreList($event){
    this.selectedStoreListDetails = [];
    if ($event.selected) {
        this.selectedStoreListDetails.push(...$event.items);
    }
    // this.formDataService.setSelectedStoreListDetails(this.selectedStoreListDetails);
    this.storeList$.next(this.selectedStoreListDetails);
  }

  handleDownloadTemplate() {
    console.log("download click");
    var posIdsList = [];
    this.selectedStoreListDetails.map((store) => {
      posIdsList.push(store.posId);
    });
    this.downloadTemplate(posIdsList);
  }

  downloadTemplate(posIdsList) {
    this.viewSubscription = this.storeService.downloadTemplate(this._router.url, posIdsList).subscribe(resp => {
      if (resp.status == 200) {
        let blob = new Blob([(<any>resp)._body], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8' })
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(blob);
        link.download = "PricingTemplate.xlsx";
        link.click();
        window.URL.revokeObjectURL(link.href);
      } else {
        //server error
      }
    })
  }

  hideShowAssortment() {
    this.formDataService.setWorkFlowSelection('hideShowAssortment');
    this.navigateToPricing();
  }
  setCurrentStoreListContent(startIndex:number, endIndex:number):void{
    this.currentStoreListContent = this.storeListTotalContent["storePricingContent"]["storePricingList"].slice( startIndex, endIndex+1);
  }

  handlePageChange($event): void {
    if( !this.storeListTotalContent ) return;
    if( $event.pageConfig.currentPage == this.pagination.currentPage
        || $event.pageConfig.endIndex < this.storeListTotalContent["storePricingContent"]["storePricingList"].length ) {
      this.setCurrentStoreListContent( $event.pageConfig.startIndex, $event.pageConfig.endIndex);
    } else {
      this.viewSubscription = this.storeService.fetchStoreList(
        this._router.url,
        { "currentPage": $event.pageConfig.currentPage, "pageSize": this.environment.storeListTableRecordsCount })
        .subscribe( (storeList: any) => {
          this.storeListTotalContent["storePricingContent"]["storePricingList"] = this.storeListTotalContent["storePricingContent"]["storePricingList"].concat(storeList["storePricingContent"].storePricingList);
          this.setCurrentStoreListContent( $event.pageConfig.startIndex, $event.pageConfig.endIndex);
        });
    }
  }

}
