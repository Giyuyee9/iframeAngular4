import { Injectable } from '@angular/core';
import {HttpAuthService} from '../core/http-auth.service';
import {RequestOptions, Headers, ResponseContentType} from '@angular/http';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';
import 'rxjs/add/operator/switchMap';

import {StoreDetails} from "../shared/models/store-details.model";
import {StoreListDetails} from '../shared/models/storelist-details.model';
import {StoreDetailsWrapper} from '../shared/models/store-details-wrapper.model';
import { environment } from '../../environments/environment';

@Injectable()
export class StoreslistService {

  constructor(private http: HttpAuthService) { }
  storeListAPIUrl : string;
  updateStorePricingStausAPIUrl: string;

  fetchStoreList(routepath: string, data: any): Observable<StoreListDetails > {
    // this.storeListAPIUrl = '/assets/api/storeList.json';
    // return this.http.get(this.storeListAPIUrl)
     return this.http.post(environment.getStoreListAPIUrl, data)
     .map((res: Response) => res.json())
     .map((res: any) => {
      return new StoreListDetails().deserialize(res)
      })
      .catch((error: any) => Observable.throw(error.json()));
  }

  downloadTemplate(url, posIdsList) {
    let headers = new Headers();
    headers.append('Content-type', 'application/json');
    headers.append('accept', 'application/octet-stream');
    return this.http.post(environment.downloadPriceTemplateAPIUrl, { "posIds": posIdsList }, {
        headers: headers,
        responseType: ResponseContentType.Blob
    }).map(resp =>
        //new Blob([(<any>res)._body], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8' })
        resp
        )
        .catch((error: any) => Observable.throw(error.json()));
  }
}
