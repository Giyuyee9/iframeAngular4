import { TestBed, inject } from '@angular/core/testing';

import { StoreslistService } from './storeslist.service';

describe('StoreslistService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [StoreslistService]
    });
  });

  it('should be created', inject([StoreslistService], (service: StoreslistService) => {
    expect(service).toBeTruthy();
  }));
});
