import { NgModule, ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import {SharedModule} from '../shared/shared.module';
import { TableviewModule, HeadernavModule, ToggleButtonModule } from 'pricingweb-uicomponents';
import { StoreslistRoutingModule, routedComponents } from './storeslist-routing.module';
import { StoreslistService } from './storeslist.service';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    SharedModule,
    StoreslistRoutingModule,
    TableviewModule,
    HeadernavModule,
    ToggleButtonModule,
  ],
  declarations: [routedComponents],
  exports: [routedComponents]
})
export class StoreslistModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: StoreslistModule,
      providers: [StoreslistService]

    };
  }
}
