import { NgModule, ModuleWithProviders} from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProductsRoutingModule, routedComponents} from './products-routing.module';
import { ListboxitemModule } from 'pricingweb-uicomponents';
import { ProductsListService } from './products-list.service';
import {SharedModule} from '../shared/shared.module';

@NgModule({
  imports: [
    CommonModule,
    ProductsRoutingModule,
    ListboxitemModule,
    SharedModule
  ],
  declarations: [routedComponents]
})
export class ProductsModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: ProductsModule,
      providers: [ProductsListService]

    };
  }
}
