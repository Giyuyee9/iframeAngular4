import { Component, OnInit } from '@angular/core';
import {Subscription} from 'rxjs/Subscription';
import {Router} from '@angular/router';

import { ProductsListService } from '../products-list.service';
import { FormDataService } from '../../data/form-data.service';
import { ProductlistDetails } from '../../shared/models/productlist-details.model';
import {ProductList} from '../../shared/models/product-list.model';
import {StoreListDetails} from '../../shared/models/storelist-details.model';
import {StoreDetails} from '../../shared/models/store-details.model';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.scss']
})
export class ProductListComponent implements OnInit {

  productListDetails : ProductlistDetails;
  productsList: ProductList[]
  selected = false;
  selectedLobItem: string = '';
  loading: boolean = true;
  currentWorkflow: string;
  nextStep: string;
  selectedStores: StoreListDetails;
  selectedStoresList: StoreDetails[] =[];
  selectedStoreDetails: StoreDetails;
  storeWorkFlow: boolean = false;
  private viewSubscription: Subscription;

  constructor(private _router: Router,
              private productsListService: ProductsListService,
              private formDataService: FormDataService) { }

  ngOnInit() {
    this.selectedStores = this.formDataService.getSelectedStoreListDetails();
    this.productListDetails = this.formDataService.getProductsListDetails();
    let posIds = [];
    if(this.selectedStores) {
      this.selectedStoreDetails = this.selectedStores.storeList[0];
      if (this.selectedStores.storeList.length > 0) {
        this.selectedStores.storeList.map((item) => {
        posIds.push(item.posId);
        });
      }
    }
    else {
      this._router.navigate(['/storeslist']);
    }
        // console.log('Personal feature loaded!');
    if (this.productListDetails &&
        this.productListDetails.selectedLobItem &&
        this.productListDetails.lobList) {
      this.productsList = this.productListDetails.lobList;
      this.productsList.map((lobItem: ProductList) => {
        if(lobItem.selected) {
          this.selectedLobItem = lobItem.lob;
        }
      });

      this.loading = false;
    }
    else {
      this.viewSubscription = this.productsListService.fetchProductList(posIds).subscribe((productListDetails: any) => {
        console.log(productListDetails);
        this.productsList = productListDetails.lobList;
        this.loading = false;
      });
    }
  }
  onItemSelected(item) {
    this.productsList.map((lobItem: ProductList) => { lobItem.selected = false });
    item.selected = true;
    this.selectedLobItem = item.lob;
    setTimeout(() => {this.onSaveProductList(this.selectedLobItem)}, 300);

  }
  onSaveProductList(selectedLobItem: string) {
    this.formDataService.setProductsListDetails(
    {
      selectedLobItem: selectedLobItem,
      productsList: this.productsList
    });
    this._router.navigate(['/viewpricing']);
  }

  getLobItemStyleClass(lobItem: string) {
    return lobItem.toLowerCase();
  }

}
