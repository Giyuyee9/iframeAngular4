import { Injectable } from '@angular/core';
import {RequestOptions, Headers} from '@angular/http';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

import {HttpAuthService} from '../core/http-auth.service';
import {ProductlistDetails} from '../shared/models/productlist-details.model';
import { environment } from '../../environments/environment';

@Injectable()
export class ProductsListService {

  lobListAPIUrl : string;

  constructor(private http: HttpAuthService) { }

  fetchProductList(posIds: string[]): Observable<ProductlistDetails> {
     this.lobListAPIUrl = environment.getLobListAPIUrl;
     return this.http.post(this.lobListAPIUrl, { posIds: posIds })
    // this.lobListAPIUrl = '/assets/api/lobList.json';
    // return this.http.get(this.lobListAPIUrl)
    .map((res: Response) => res.json())
    .map((res: any) => {
      return new ProductlistDetails().deserialize(res.lobList)
    })
    .catch((error: any) => Observable.throw(error.json()));
  }
}
